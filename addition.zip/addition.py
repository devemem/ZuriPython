a = 5
b = 9
result = a + b
print(a,"+",b,"=",result)
